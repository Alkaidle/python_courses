name = 'jackfrued'
fruits = ['apple', 'orange', 'grape']
owners = {'name': '骆昊', 'age': 40, 'gender': True}

# if name != '' and len(fruits) > 0 and len(owners.keys()) > 0:
#     print('Jackfrued love fruits.')

if name and fruits and owners:
    print('Jackfrued love fruits.')
