fruits = ['orange', 'grape', 'pitaya', 'blueberry']

# index = 0
# for fruit in fruits:
#     print(index, ':', fruit)
#     index += 1

for index, fruit in enumerate(fruits):
    print(index, ':', fruit)
